<?php

define('TITLE', 'Xem tất cả các Trích dẫn');
include '../partials/header.php';

echo '<h2>Tất cả các Trích dẫn</h2>';

include '../partials/check_admin.php';

echo '<p>Trang đang được xây dựng...</p>';

include '../partials/footer.php';
?>